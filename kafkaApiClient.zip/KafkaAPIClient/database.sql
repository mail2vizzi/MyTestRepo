CREATE TABLE car(
  id int NOT NULL IDENTITY(1,1),
  car_name varchar(250) DEFAULT NULL,
  description varchar(400) DEFAULT NULL,
  price numeric(18, 0) DEFAULT NULL,
  PRIMARY KEY (id)
);