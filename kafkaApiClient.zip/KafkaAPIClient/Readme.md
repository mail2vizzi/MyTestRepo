
Compile the code using 

mvn compile assembly:single