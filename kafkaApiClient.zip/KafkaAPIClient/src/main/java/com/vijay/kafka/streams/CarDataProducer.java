package com.vijay.kafka.streams;

import org.apache.kafka.clients.producer.*;

import com.google.common.hash.Hashing;
import com.google.gson.Gson;
import com.vijay.jpa.Car;
import com.vijay.utils.Utility;

import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.util.Scanner;

/**
 * Created by sunilpatil on 1/2/16.
 */
public class CarDataProducer {
    private static Scanner in;
    public static void main(String[] argv)throws Exception {
    	argv  = new String[] {"car-data-topic"};
        if (argv.length != 1) {
            System.err.println("Please specify 1 parameters ");
            System.exit(-1);
        }
        String topicName = argv[0];
        in = new Scanner(System.in);
        System.out.println("Enter message(type exit to quit)");

        //Configure the Producer
        Properties configProperties = new Properties();
        configProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,"localhost:9092");
        configProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.ByteArraySerializer");
        configProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,"org.apache.kafka.common.serialization.StringSerializer");

        org.apache.kafka.clients.producer.Producer producer = new KafkaProducer(configProperties);
        String line = in.nextLine();
        Gson mapper = new Gson();
        while(!line.equals("exit")) {
        	Car carRecord = Utility.generateCarRecord();
			String json = mapper.toJson(carRecord);
			String hash = Hashing.sha256()
					  .hashString(json, StandardCharsets.UTF_8)
					  .toString();
            ProducerRecord<String, String> rec = new ProducerRecord<String, String>(topicName, hash, line);
            producer.send(rec, new Callback() {
                public void onCompletion(RecordMetadata metadata, Exception exception) {
                    System.out.println("Message sent to topic ->" + metadata.topic() +" stored at offset->" + metadata.offset());
                }
            });
            line = in.nextLine();
        }
        in.close();
        producer.close();
    }
}
