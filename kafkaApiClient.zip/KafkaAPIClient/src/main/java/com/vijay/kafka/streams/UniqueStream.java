/**
 * 
 */
package com.vijay.kafka.streams;

import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;

/**
 * @author Sireesha Vijay
 *
 */
public class UniqueStream {
	public static void main(String[] args) {
		
		Properties configProperties = new Properties();
        configProperties.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        configProperties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.ByteArrayDeserializer");
        configProperties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
//        configProperties.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
//        configProperties.put(ConsumerConfig.CLIENT_ID_CONFIG, "simple");
        String topicname ="car-data-topic";
        StreamsBuilder builder = new StreamsBuilder();
//       builder.stream(topicname, Consumed.with(Serdes.String(), Serdes.String())).transform(new FindDistinctCars(()), stateStoreNames);
        
        
        
		
	}

}
