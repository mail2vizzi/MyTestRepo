package com.vijay.jpa;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/*
//Compile mvn compile
//Run: mvn exec:java -Dexec.mainClass="net.roseindia.AppTest"

*/
/**
 * @author Deepak Kumar More tutorials at http://www.roseindia.net
 */

public class AppTest {

	private static final String PERSISTENCE_UNIT_NAME = "psunit1";
	private static EntityManagerFactory factory;

	public static void main(String[] args) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();

		em.getTransaction().begin();

		Car car = new Car();
		car.setCarName("Zenvo ST1");
		car.setDescription("Zenvo ST1 is most expensive Car in world.");
		car.setPrice(1200000.00);
		em.persist(car);

		// Select all the record from Car table
		Query query = em.createQuery("SELECT o FROM Car o");
		List lst = query.getResultList();
		Iterator it = lst.iterator();
		while (it.hasNext()) {
			Car obj = (Car) it.next();
			System.out.println("Id: " + obj.getId());
			System.out.println("Name: " + obj.getCarName());
			System.out.println("Description: " + obj.getDescription());
			System.out.println("Price: " + obj.getPrice());
		}
		// Commit
		em.getTransaction().commit();

		/* Update Example */
		// Load and update Entity Eample
		em.getTransaction().begin();
		// find
		Car carObj = em.find(Car.class, 1);
		carObj.setDescription("Car description Updated");
		// update
		em.merge(carObj);
		// Commit
		em.getTransaction().commit();

		// Select all the record from Car table
		query = em.createQuery("SELECT o FROM Car o");
		lst = query.getResultList();
		it = lst.iterator();
		while (it.hasNext()) {
			Car obj = (Car) it.next();
			System.out.println("Id: " + obj.getId());
			System.out.println("Name: " + obj.getCarName());
			System.out.println("Description: " + obj.getDescription());
			System.out.println("Price: " + obj.getPrice());
		}

		// Delete Example
		em.getTransaction().begin();

		// find
		Car cObj = em.find(Car.class, 2);
		// delete
		em.remove(cObj);
		// Commit
		em.getTransaction().commit();

		em.close();

	}
}