package com.vijay.jpa;

import javax.persistence.*;

/**
 * @author Deepak Kumar More tutorials at http://www.roseindia.net
 */

@Entity
@Table(name = "car")
public class Car {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "car_name")
	private String carName;

	@Column(name = "description")
	private String description;

	@Column(name = "price")
	private Double price;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Car [carName=" + carName + ", description=" + description + ", price=" + price + "]";
	}
	
	
}