package com.vijay.hibernate;

import java.io.File;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HibernateUtil {
	private static final SessionFactory sessionFactory;
	static {
		try {
//			sessionFactory = new AnnotationConfiguration().configure().buildSessionFactory();
			sessionFactory = buildSessionFactory();
		} catch (Throwable th) {
			System.err.println("Enitial SessionFactory creation failed" + th);
			throw new ExceptionInInitializerError(th);
		}
	}
	
	  private static SessionFactory buildSessionFactory() {
	        // Create the SessionFactory from hibernate.cfg.xml
	        return new AnnotationConfiguration().configure(new File("hibernate.cfg.xml")).buildSessionFactory();
	    }


	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}