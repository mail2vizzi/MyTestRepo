package com.vijay.hibernate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class MSSQLConnectionTest {

	public static void main(String[] args) throws Exception {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//		Connection connection = DriverManager.getConnection("jdbc:microsoft:sqlserver://DESKTOP-27FPMUS:1433/Test", "admin","admin");
		Connection connection = DriverManager.getConnection("jdbc:sqlserver://DESKTOP-27FPMUS:1433;databaseName=Test;integratedSecurity=false;", "admin", "admin");
		Statement stmt = connection.createStatement();
		if(!connection.isClosed()) {
			System.out.println("connected");
			connection.close();
		}
			

	}

}
