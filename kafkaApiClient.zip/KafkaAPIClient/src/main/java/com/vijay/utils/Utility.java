package com.vijay.utils;

import java.nio.charset.StandardCharsets;
import java.util.Random;

import com.google.common.hash.Hashing;
import com.google.gson.Gson;
import com.vijay.jpa.Car;

public class Utility {
	
	public static Car generateCarRecord() {
		
		String[] brand = new String[]{"Honda"};
		String[] model = new String[] {"Jazz","Civic","Accord", "HRV", "CRV", "Pilot"};
		String[] train = new String[] {"LX","LX-P", "EX","EX-L", "Touring"};
		double[] price = new double[] {21000.00, 24500.00, 26050.00, 28000.00, 30500.00};
		Car car = new Car();
		car.setCarName(brand[0]+":"+model[new Random().nextInt(model.length)]);
		car.setDescription(car.getCarName()+":"+train[new Random().nextInt(train.length)]);
		car.setPrice(price[new Random().nextInt(price.length)]);
		return car;
	}
	
	public static void main(String[] ar) {
		Gson mapper = new Gson();
		for(int i= 0; i<20;i++) {
			
			Car carRecord = generateCarRecord();
			String json = mapper.toJson(carRecord);
			String sha256hex = Hashing.sha256()
					  .hashString(json, StandardCharsets.UTF_8)
					  .toString();
			System.out.println(sha256hex+" ["+json+"]");
		}
	}

}
